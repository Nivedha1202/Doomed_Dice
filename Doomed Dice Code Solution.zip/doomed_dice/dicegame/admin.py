from dicegame.models import DiceGame
class AdminSite:
    def __init__(self):
        self.registry = {}

    def register(self, model):
        self.registry[model.__name__] = model

admin_site = AdminSite()

class ModelAdmin:
    pass

admin = ModelAdmin()
admin_site.register(DiceGame)

