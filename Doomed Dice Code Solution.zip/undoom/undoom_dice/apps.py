from django.apps import AppConfig


class UndoomDiceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'undoom_dice'
