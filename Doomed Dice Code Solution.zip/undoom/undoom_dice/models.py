# undoom_dice/models.py
from django.db import models
from .utils import undoom_dice

class Result(models.Model):
    face_a = models.IntegerField()
    face_b = models.IntegerField()
    total = models.IntegerField()

    @staticmethod
    def calculate_results():
        # Your existing calculation logic here
        pass

    @staticmethod
    def generate_results():
        die_a = [1, 2, 3, 4, 5, 6]
        die_b = die_a
        new_die_a, new_die_b = undoom_dice(die_a, die_b)

        total_combinations = 0

        for face_a in new_die_a:
            for face_b in new_die_b:
                total_combinations += 1
                total = face_a + face_b
                Result.objects.create(face_a=face_a, face_b=face_b, total=total)

        return total_combinations
