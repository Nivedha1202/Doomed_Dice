# undoom_dice/urls.py
from django.conf import settings
from django.urls import path, include
from .views import undoom_dice_view

app_name = 'undoom_dice'

# Define the show_toolbar function
def show_toolbar(request):
    return settings.DEBUG

urlpatterns = [
    path('results/', undoom_dice_view, name='djdt_some_view'),
]

# Additional configuration for Debug Toolbar if needed
if settings.DEBUG:
    import debug_toolbar
    urlpatterns += [
        path('__debug__/', include(debug_toolbar.urls)),
    ]
