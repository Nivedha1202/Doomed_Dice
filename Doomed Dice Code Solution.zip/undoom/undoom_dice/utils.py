#possible faces for Die A and Die B
possible_die_faces_a = [0, 1, 2, 3, 4]
possible_die_faces_b = [1, 2, 3, 4, 5, 6, 7, 8]

#total number of spots on Die B across all its faces based on assumption
total_spots = 42
original_sum_probabilities = {2: 1, 4: 3, 5: 4, 6: 5, 7: 6, 9: 4, 3: 2, 8: 5, 10: 3, 11: 2, 12: 1}

#All possible combinations for Die A
def die_a_combinations(curr_die, valid_combos_die_a):    
    if len(curr_die) == 6:
        valid_combos_die_a.append(curr_die.copy())
        return 
    
    for face in possible_die_faces_a:
        die_a_combinations(curr_die + [face], valid_combos_die_a)    

#All possible combinations for Die B
def die_b_combinations(prev_face_index, curr_die, curr_spot_count, valid_combos_die_b):
    if curr_spot_count > total_spots:
        return
    
    if len(curr_die) == 6:
        if curr_spot_count == total_spots:
            valid_combos_die_b.append(curr_die.copy())
        return
    
    for i in range(prev_face_index + 1, len(possible_die_faces_b)):
        die_b_combinations(i, curr_die + [possible_die_faces_b[i]], curr_spot_count + possible_die_faces_b[i], valid_combos_die_b)

#Sum probabilities for a given set of Die A and Die B
def calculate_dice_probabilities(original_die_a, original_die_b):
    probability = {}
    for die_face_a in original_die_a:
        for die_face_b in original_die_b:
            if die_face_a + die_face_b in probability:
                probability[die_face_b + die_face_a] += 1
            else:
                probability[die_face_b + die_face_a] = 1
      
    return probability

#To check if the given set of Die A and Die B has the desired sum probabilities
def is_valid_dice(original_die_a, original_die_b):
    new_probabilities = calculate_dice_probabilities(original_die_a, original_die_b)
    return new_probabilities == original_sum_probabilities

#Function that finds the valid combination of Die A and Die B
def undoom_dice(original_die_a, original_die_b):
    valid_combos_die_a = []
    die_a_combinations([], valid_combos_die_a)

    for die_combination_a in valid_combos_die_a:
        valid_combos_die_b = []
        die_b_combinations(-1, [], sum(die_combination_a), valid_combos_die_b)
        for die_combination_b in valid_combos_die_b:
            if is_valid_dice(die_combination_a, die_combination_b):
                return original_die_a, original_die_b, die_combination_a, die_combination_b

original_die_a = [1, 2, 3, 4, 5, 6]
original_die_b = original_die_a

result = undoom_dice(original_die_a, original_die_b)

if result:
    print("Original Die A:", result[0])
    print("Original Die B:", result[1])
    print("New Die A:", result[2])
    print("New Die B:", result[3])
