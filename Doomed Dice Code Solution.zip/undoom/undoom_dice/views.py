from django.shortcuts import render
from .utils import undoom_dice

def undoom_dice_view(request):
    original_die_a = [1,2,3,4,5,6]
    original_die_b = original_die_a
    
    result = undoom_dice(original_die_a, original_die_b)
    
    context = {
        'original_die_a': result[0],
        'original_die_b': result[1],
        'new_die_a': result[2],
        'new_die_b': result[3],
    }
    
    return render(request, 'undoom_dice/results.html', context)
