def undoom_dice(die_a, die_b):
    # Calculate the current probability distribution for Die A
    current_distribution = {}
    total_combinations = 0

    for face_a in die_a:
        for face_b in die_b:
            total_combinations += 1
            total = face_a + face_b
            current_distribution[face_a] = current_distribution.get(face_a, 0) + 1

    # Calculate the probability of each total for Die A
    current_probabilities = {key: value / total_combinations for key, value in current_distribution.items()}

    # Calculate the desired probability of each total for Die A (assuming uniform distribution)
    desired_probabilities = {key: 1 / 6 for key in range(1, 7)}

    # Ensure all totals are present in current_probabilities
    for key in desired_probabilities:
        current_probabilities.setdefault(key, 0)

    # Calculate the scaling factor for each total of Die A
    scaling_factors = {face: desired_probabilities[face] / (current_probabilities[face] + 1e-6) for face in die_a}

    # Apply the scaling factors to get the new faces for Die A
    new_die_a = [min(int(face * scaling_factors[face] + 0.5), 4) for face in die_a]

    # New faces for Die B can remain the same
    new_die_b = die_b

    return new_die_a, new_die_b
