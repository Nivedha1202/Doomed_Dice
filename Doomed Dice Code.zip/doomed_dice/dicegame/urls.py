# dicegame/urls.py
from django.urls import path
from .views import dicegame_results

urlpatterns = [
    path('results/', dicegame_results, name='dicegame_results'),
]


