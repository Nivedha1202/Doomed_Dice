from django.shortcuts import render
from .models import DiceGame

def dicegame_results(request):
    k = 2  # Number of dice rolls
    combinations = DiceGame.calculate_combinations(k)
    distribution_matrix = DiceGame.calculate_combinations(k)
    probability_matrix = DiceGame.calculate_probability_matrix(combinations)

    # Save data to the database
    for combination in combinations:
        face_a, face_b = combination
        total = face_a + face_b
        DiceGame.objects.create(die_a=face_a, die_b=face_b, total=total)

    return render(request, 'dicegame/results.html', {
        'total_combinations': len(combinations),
        'distribution_matrix': distribution_matrix,
        'probability_matrix': probability_matrix,
    })

