from django.db import models

class DiceGame(models.Model):
    die_a = models.IntegerField()
    die_b = models.IntegerField()
    total = models.IntegerField()

    @staticmethod
    def calculate_combinations(k):
        res = [(i,) for i in range(1, 7)]
        for i in range(1, k):
            new_res = []
            for comb in res:
                for j in range(1, 7):
                    new_res.append(comb + (j,))
            res = new_res
        return res

    @staticmethod
    def calculate_probability_matrix(combinations):
        total_combinations = len(combinations)
        sum_counts = {}
        for combination in combinations:
            total = sum(combination)
            sum_counts[total] = sum_counts.get(total, 0) + 1

        probability_matrix = {key: value / total_combinations for key, value in sum_counts.items()}
        return probability_matrix
